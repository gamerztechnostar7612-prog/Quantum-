const $ = id => document.getElementById(id);

const weatherCodes = {
  0:["Clear sky","☀️"], 1:["Mainly clear","🌤️"], 2:["Partly cloudy","⛅"], 3:["Overcast","☁️"],
  45:["Fog","🌫️"], 48:["Rime fog","🌫️"], 51:["Light drizzle","🌦️"], 53:["Drizzle","🌦️"],
  55:["Heavy drizzle","🌧️"], 61:["Light rain","🌦️"], 63:["Rain","🌧️"], 65:["Heavy rain","🌧️"],
  71:["Light snow","🌨️"], 73:["Snow","🌨️"], 75:["Heavy snow","❄️"], 80:["Rain showers","🌦️"],
  81:["Rain showers","🌧️"], 82:["Heavy showers","⛈️"], 95:["Thunderstorm","⛈️"],
  96:["Thunderstorm + hail","⛈️"], 99:["Thunderstorm + hail","⛈️"]
};
const directions = ["N","NE","E","SE","S","SW","W","NW"];

function codeInfo(code) { return weatherCodes[code] || ["Unknown","🌡️"]; }
function windDir(deg) { return directions[Math.round(deg / 45) % 8]; }
function aqiLabel(aqi) {
  if (aqi <= 20) return "Good";
  if (aqi <= 40) return "Fair";
  if (aqi <= 60) return "Moderate";
  if (aqi <= 80) return "Poor";
  if (aqi <= 100) return "Very poor";
  return "Extremely poor";
}
function timeShort(iso) {
  return new Date(iso).toLocaleTimeString([], {hour:"numeric"});
}
function dayName(date) {
  return new Date(date).toLocaleDateString([], {weekday:"short"});
}

async function geocode(city) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Could not search for the city.");
  const data = await r.json();
  if (!data.results?.length) throw new Error("City not found.");
  return data.results[0];
}

async function getWeather(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,visibility` +
    `&hourly=temperature_2m,weather_code,precipitation_probability,uv_index` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,sunrise,sunset` +
    `&timezone=auto&forecast_days=7`;
  const airUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}` +
    `&current=us_aqi&timezone=auto`;
  const [w, a] = await Promise.all([fetch(url), fetch(airUrl)]);
  if (!w.ok || !a.ok) throw new Error("Weather service is unavailable.");
  return {weather: await w.json(), air: await a.json()};
}

function render(place, data) {
  const w = data.weather, c = w.current, h = w.hourly, d = w.daily;
  const [condition, icon] = codeInfo(c.weather_code);
  $("weather").classList.remove("hidden");
  $("place").textContent = `${place.name}${place.admin1 ? ", " + place.admin1 : ""}`;
  $("date").textContent = new Date(c.time).toLocaleString([], {dateStyle:"full", timeStyle:"short"});
  $("temp").textContent = Math.round(c.temperature_2m);
  $("feels").textContent = Math.round(c.apparent_temperature);
  $("condition").textContent = condition;
  $("weatherIcon").textContent = icon;
  $("humidity").textContent = `${c.relative_humidity_2m}%`;
  $("wind").textContent = `${Math.round(c.wind_speed_10m)} km/h`;
  $("direction").textContent = `${windDir(c.wind_direction_10m)} (${Math.round(c.wind_direction_10m)}°)`;
  const aqi = data.air.current?.us_aqi;
  $("aqi").textContent = aqi ?? "—";
  $("aqiText").textContent = aqi == null ? "Unavailable" : aqiLabel(aqi);
  $("visibility").textContent = `${(c.visibility / 1000).toFixed(1)} km`;
  $("pressure").textContent = `${Math.round(c.pressure_msl)} hPa`;
  $("uv").textContent = h.uv_index[0]?.toFixed(1) ?? "—";
  $("rain").textContent = `${h.precipitation_probability[0] ?? 0}%`;

  const currentHour = new Date(c.time).getTime();
  let start = h.time.findIndex(t => new Date(t).getTime() >= currentHour);
  if (start < 0) start = 0;
  $("hourly").innerHTML = h.time.slice(start, start+12).map((t,i) => {
    const idx = start+i, [cond, ico] = codeInfo(h.weather_code[idx]);
    return `<div class="hour"><div>${timeShort(t)}</div><div class="icon">${ico}</div>
      <strong>${Math.round(h.temperature_2m[idx])}°</strong><div class="muted">${h.precipitation_probability[idx] ?? 0}% rain</div></div>`;
  }).join("");

  $("daily").innerHTML = d.time.map((date,i) => {
    const [cond, ico] = codeInfo(d.weather_code[i]);
    return `<div class="daily-row"><strong>${i===0 ? "Today" : dayName(date)}</strong>
      <span>${ico} ${cond}</span><span>${Math.round(d.temperature_2m_max[i])}° / ${Math.round(d.temperature_2m_min[i])}°</span>
      <span>💧 ${d.precipitation_probability_max[i] ?? 0}%</span></div>`;
  }).join("");
}

async function loadCity(city) {
  $("status").textContent = "Loading weather…";
  $("status").classList.remove("error");
  try {
    const place = await geocode(city);
    const data = await getWeather(place.latitude, place.longitude);
    render(place, data);
    $("status").textContent = "Updated just now";
  } catch (e) {
    $("status").textContent = e.message;
    $("status").classList.add("error");
  }
}

async function loadLocation() {
  if (!navigator.geolocation) {
    $("status").textContent = "Geolocation is not supported by this browser.";
    return;
  }
  $("status").textContent = "Getting your location…";
  navigator.geolocation.getCurrentPosition(async pos => {
    try {
      const lat = pos.coords.latitude, lon = pos.coords.longitude;
      const data = await getWeather(lat, lon);
      render({name:"My location"}, data);
      $("status").textContent = "Using your current location";
    } catch(e) {
      $("status").textContent = e.message;
      $("status").classList.add("error");
    }
  }, () => {
    $("status").textContent = "Location permission was denied.";
    $("status").classList.add("error");
  });
}

$("searchBtn").addEventListener("click", () => {
  const city = $("cityInput").value.trim();
  if (city) loadCity(city);
});
$("cityInput").addEventListener("keydown", e => {
  if (e.key === "Enter") $("searchBtn").click();
});
$("locationBtn").addEventListener("click", loadLocation);

loadCity("Bokaro");
